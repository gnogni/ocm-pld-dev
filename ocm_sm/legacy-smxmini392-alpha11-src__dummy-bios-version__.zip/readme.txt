OCM-PLD v3.9.2 for SM-X Mini  { Legacy Package }
================================================

To add the SM-X Mini source code back to the 'ocm_sm' project,
simply overwrite the 'firmware\' and 'ocm_sm\' folders of this package
in the corresponding path 'ocm-pld v3.9.2\'.

THE FIMWARE THAT CAN BE OBTAINED FOR SM-X MINI HAS NOT BEEN TESTED BY ME AND
I DO NOT KNOW IF THEM ARE USABLE, SO USING THESE FIMWARE MAY BRICK THE MACHINE.
THEREFORE, USE OF THIS PROCEDURE "IS" ONLY AT YOUR OWN RISK AND RESPONSIBILITY.


______________
KdL 2023.08.26
